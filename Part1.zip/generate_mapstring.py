#!/usr/bin/env python

import os

for k in os.listdir("lmdb"):
	print "/home/mohanty/data/final_dataset/lmdb/"+k
