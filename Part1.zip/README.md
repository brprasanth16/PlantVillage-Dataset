# PlantVillage-Dataset

## Download dataset

With [git](https://git-scm.com/downloads) installed, you can download the dataset by : 
```
git clone https://github.com/spMohanty/PlantVillage-Dataset
cd PlantVillage-Dataset
```
The different versions of the dataset are present in the `raw` directory : 
* `color` : Original RGB images
* `grayscale` : grayscaled version of the raw images
* `segmented` : RGB images with just the leaf segmented and color corrected.

TO-DO : Add Usage Documentation. In case of any confusion while trying to use this code now, please shoot an email to `sharada.mohanty@epfl.ch`
